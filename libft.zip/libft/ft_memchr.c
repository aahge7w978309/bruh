#include "libft.h"

void *ft_memchr(const void *ptr, int value, size_t num)
{
    char *p;
    size_t i;

    p = (char *)ptr;
    i = 0;
    while (i <= num)
    {
        if (value == *p)
            break;
        p++;
        i++;
    }
    return (p);
}