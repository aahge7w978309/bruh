#include <stdlib.h>
#include "libft.h"

char *ft_substr(char const *s, unsigned int start, size_t len)
{
    size_t i;
    size_t j;
    char *sub;

    if (!s || !start || !len)
        return (NULL);
    i = (size_t)start;
    j = 0;
    sub = (char *)malloc(sizeof(char) * len);
    if (!sub)
        return (0);
    while (j <= len)
    {
        sub[j] = s[i];
        i++;
        j++;
    }
    sub[j] = '\0';
    return (sub);
}