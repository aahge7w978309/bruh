#include "libft.h"

int is_set(char *str, char c)
{
    size_t i;

    i = 0;
    while (str[i])
    {
        if (c == str[i])
            return (1);
        i++;
    }
    return (0);
}

char *trim(size_t start, size_t end, char *s1)
{
    size_t i;
    size_t j;
    size_t r;
    char *str;

    r = end - start;
    i = start;
    str = (char *)malloc((sizeof(char) * r) + 1);
    if (!str)
        return (0);
    j = 0;
    while (j <= r)
    {
        str[j] = s1[i];
        j++;
        i++;
    }
    str[j] = '\0';
    return (str);
}

char *ft_strtrim(char const *s1, char const *set)
{
    size_t i;
    size_t j;
    char *s;
    char *t;

    if (!s1 || !set)
        return (NULL);
    i = 0;
    s = (char *)s1;
    t = (char *)set;
    j = ft_strlen(s) - 1;
    while (is_set(t, s[i]))
    {
        i++;
    }
    while (is_set(t, s[j]))
    {
        j--;
    }
    return (trim(i, j, s));
}