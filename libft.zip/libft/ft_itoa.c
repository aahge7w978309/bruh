#include <stdlib.h>
#include "libft.h"

long int clen(long int nb)
{
    long int i;

    i = 0;
    if (nb < 0)
    {
        i++;
        nb *= -1;
    }
    while (nb > 0)
    {
        i++;
        nb /= 10;
    }
    return (i);
}

char *itoing(char *r, long int nb, long int len)
{
    
    r[len] = '\0';
    if (nb < 0)
    {
        r[0] = '-';
        nb = -nb;
    }
    while (nb > 0)
    {
        r[--len] = (nb % 10) + 48;
        nb /= 10;
    }
    return (r);
}

char *ft_itoa(int n)
{
    int nb;
    char *r;
    long int len;

    if (n == 0)
    {
        r = malloc(2);
        r[1] = '\0';
        r[0] = '0';
        return (r);
    }
    nb = n;
    len = clen(n);
    r = (char *)malloc(sizeof(char) * (len + 1));
    if (!r)
        return (0);
    return (itoing(r, nb, len));
}