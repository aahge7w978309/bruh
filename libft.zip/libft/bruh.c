#include "libft.h"
#include <stdio.h>
int main() {
    char str[] = "Hello,World,This,is,a,test";
    char delimiter = ',';
    char **result;
    int i = 0;

    // Call ft_split to split the string
    result = ft_split(str, delimiter);

    if (result == NULL) {
        printf("Failed to split the string.\n");
        return 1;
    }

    // Loop through the result array and print each substring
    printf("Splitting the string: '%s' by '%c'\n", str, delimiter);
    while (result[i] != NULL) {
        printf("Substring %d: %s\n", i, result[i]);
        free(result[i]);  // Free each substring
        i++;
    }
    free(result);  // Free the array itself

    return 0;
}

