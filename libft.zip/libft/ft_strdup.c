#include "libft.h"
#include <stdlib.h>

char *ft_strdup(const char *s)
{
    size_t i;
    char *str;

    while (s[i])
        i++;
    str = (char *)malloc(sizeof(char) * i);
    if (!str)
        return (0);
    i = 0;
    while (s[i])
    {
        str[i] = s[i];
        i++;
    }
    str[i] = '\0';
    return (str);
}
