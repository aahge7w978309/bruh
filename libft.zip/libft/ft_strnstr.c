#include "libft.h"

char *ft_strnstr(const char *haystack, const char *needle, size_t len)
{
    char *ne;
    char *hay;
    size_t i;
    size_t j;

    ne = (char *)needle;
    hay = (char *)haystack;
    i = 0;

    while (i < len)
    {
        j = 0;
        while (hay[i] == ne[j] && ne[j])
        {
            i++;
            j++;
        }
        if (ne[j] == '\0')
            break;
        i++;
    }
    if (j < ft_strlen(ne))
        return (0);
    hay += (i - j);
    return (hay);
}
