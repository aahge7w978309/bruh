#include <stdlib.h>
#include "libft.h"



char *ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
    if (!s || !(*f))
        return (NULL);
    size_t i;
    size_t j;
    char *str;

    i = 0;
    while (s[i])
        i++;
    str = (char *)malloc(sizeof(char) * (i + 1));
    if (!str)
        return (0);
    j = 0;
    while (j < i)
    {
        str[j] = (*f)(j, s[j]);
        j++;
    }
    str[i] = '\0';
    return (str);
}
int main()
{

}