#include "libft.h"

void *ft_memset(void *ptr, int value, size_t num)
{
    unsigned char *p;
    
    p = (unsigned char *)ptr;
    while (num > 0)
    {
        p[num] = value;
        num--;
    }
    return (ptr);
}