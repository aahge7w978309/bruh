#include "libft.h"

int ft_atoi(const char *nptr)
{
    size_t i;
    size_t r;
    size_t s;
    char *str;
    
    str = (char *)nptr;
    i = 0;
    r = 0;
    s = 1;
    while (str[i] == ' ' || (str[i] >= 8 && str[i] <= 13))
        i++;
    while (str[i] == '-' || str[i] == '+')
    {
        if (str[i] == '-')
        {
            s *= -1;
        }
        i++;
    }
    while (str[i] >= '0' && str[i] <= '9')
    {
        r *= 10;
        r += (str[i] - 48);
        i++;
    }
    return (r * s);
}
