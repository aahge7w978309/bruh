#include "libft.h"

char *ft_strchr(const char *str, int c)
{
    char *r;
    while(*str && *str != c)
    {
        str++;
    }
    r = (char *)str;
    return (r);
}
