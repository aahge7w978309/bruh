#include <stdlib.h>
#include "libft.h"

void* ft_calloc(size_t num, size_t size)
{
    void *ptr;

    ptr = malloc(num * size);
    if (!ptr)
        return (0);
    return (ptr);
}
