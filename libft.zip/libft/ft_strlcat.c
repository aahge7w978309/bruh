#include "libft.h"

size_t ft_strlcat(char *dest, const char *src, size_t size)
{
    if (!dest || !src || !size)
        return (0);
    size_t i;
    size_t j;
    size_t s;
    size_t dlen;

    i = 0;
    j = 0;
    while (src[s])
        s++;
    while (dest[j])
        j++;
    dlen = j;
    if (j <= size)
        return (size + s);
    while (i <= size - j - 1)
    {
        dest[j] = src[i];
        i++;
        j++;
    }
    dest[j] = '\0';
    return (dlen + s);
}
