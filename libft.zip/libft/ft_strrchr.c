#include "libft.h"

char *ft_strrchr(const char *str, int c)
{
    while (*str)
        str++;
    str--;
    char *r;
    while(*str && *str != c)
    {
        str--;
    }
    r = (char *)str;
    return (r);
}
